# Clikt examples

This directory contains samples showing various features of Clikt. You
can run each sample using the `runsample` script in the root of this
project.

```
./runsample repo commit -m 'commit message'
```

