application {
    mainClass.set("com.github.ajalt.clikt.samples.aliases.MainKt")
}
