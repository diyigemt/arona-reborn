# File copy sample

This example works like the `cp` command, copying files or directories.
It shows how to use `prompt` to get an input from user.

```
$ touch src.txt dest.txt
$ ./runsample copy -i src.txt dest.txt
```
