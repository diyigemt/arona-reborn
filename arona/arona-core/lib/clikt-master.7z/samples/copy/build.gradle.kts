application {
    mainClass.set("com.github.ajalt.clikt.samples.copy.MainKt")
}
