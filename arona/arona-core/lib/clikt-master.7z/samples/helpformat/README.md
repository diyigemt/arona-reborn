# Custom help formatter

This example shows how to use a custom help formatter in a command. This formatter changes the
parameter sections to be drawn in panels, changes metavars to be uppercase, and changes the colors
used.

<p align="center"><img src="screenshot.png"></p>
