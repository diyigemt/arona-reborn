# JSON Configuration files

This example shows how to read option values from JSON files using the `kotlinx.serialization`
library. It reads config files from the `config.json` file located in this directory.

```
./runsample json subcommand
```
