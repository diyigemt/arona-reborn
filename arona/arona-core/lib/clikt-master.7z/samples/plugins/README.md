# Dynamic subcommands example

This example shows how to create a complex application that registers
subcommands dynamically through dependency injection.

```
./runsample plugins --help
```
