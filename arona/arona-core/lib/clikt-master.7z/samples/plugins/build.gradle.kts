application {
    mainClass.set("com.github.ajalt.clikt.samples.plugins.MainKt")
}

dependencies {
    api(libs.kodein)
}
