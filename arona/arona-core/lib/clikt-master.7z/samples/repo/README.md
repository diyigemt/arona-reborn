# Repo example

This sample demonstrates building a complex commline app like git or hg.
It has multiple subcommands, and uses the `Context.obj` to send data
from the root command to subcommands.

```
./runsample repo --help
./runsample repo clone --help
./runsample setuser
```
