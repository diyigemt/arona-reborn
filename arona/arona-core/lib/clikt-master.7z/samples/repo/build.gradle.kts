application {
    mainClass.set("com.github.ajalt.clikt.samples.repo.MainKt")
}
