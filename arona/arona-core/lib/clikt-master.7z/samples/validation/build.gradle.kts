application {
    mainClass.set("com.github.ajalt.clikt.samples.validation.MainKt")
}
