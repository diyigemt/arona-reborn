rootProject.name = "buildSrc"

apply(from = "./repositories.settings.gradle.kts")
