package codes.laurence.warden.policy

@DslMarker
annotation class PolicyDSL
