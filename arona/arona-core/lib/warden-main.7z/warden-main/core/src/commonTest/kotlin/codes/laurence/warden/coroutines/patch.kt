package codes.laurence.warden.coroutines

expect fun runBlockingTest(testBlock: suspend () -> Unit)
